require "test_helper"

class UserTest < ActiveSupport::TestCase
  test "has a valid factory" do
    assert FactoryBot.build(:user).valid?
  end

  test "is valid with an email, password, nickname, and API token" do
    user = User.new(
      email: "test@example.com",
      password: "password",
      nickname: "test",
      api_token: "token"
    )

    assert user.valid?
  end

  test "requires a nickname" do
    user = FactoryBot.build(:user, nickname: nil)

    assert_not user.valid?
    assert_includes user.errors[:nickname], "can't be blank"
  end

  test "requires a unique nickname" do
    FactoryBot.create(:user, nickname: "test")
    user = FactoryBot.build(:user, nickname: "test")

    assert_not user.valid?
    assert_includes user.errors[:nickname], "has already been taken"
  end

  test "requires an email" do
    user = FactoryBot.build(:user, email: nil)

    assert_not user.valid?
    assert_includes user.errors[:email], "can't be blank"
  end

  test "requires a unique email" do
    skip "not yet implemented"
  end

  test "requires a password" do
    skip "not yet implemented"
  end

  test "requires an API token" do
    skip "not yet implemented"
  end

  test "sets a new user's API token" do
    skip "not yet implemented"
  end

  test "indicates a new user" do
    user = FactoryBot.build(:user, created_at: Time.current)

    assert user.new_to_site?
  end

  test "indicates an established user" do
    user = User.new(created_at: 1.month.ago)

    assert_not user.new_to_site?
  end

  test "lists a user's recipes" do
    user = FactoryBot.create(:user)
    recipe = FactoryBot.create(:recipe, user: user)

    assert_includes user.recipes, recipe
  end
end
