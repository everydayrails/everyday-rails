require "test_helper"

class RecipesTest < ActionDispatch::IntegrationTest
  test "GET index as a guest redirects to sign-in" do
    get recipes_path

    assert_redirected_to sign_in_path
  end

  test "GET index as an authenticated user displays the recipes list" do
    get recipes_path(as: FactoryBot.create(:user))

    assert_response :ok
  end

  test "POST create as a guest redirects to sign-in" do
    recipe_attributes = FactoryBot.attributes_for(:recipe,
      category_id: FactoryBot.create(:category).id
    )

    post recipes_path, params: { recipe: recipe_attributes }

    assert_redirected_to sign_in_path
  end

  test "POST create as an authenticated user redirects to the new recipe" do
    user = FactoryBot.create(:user)
    recipe_attributes = FactoryBot.attributes_for(:recipe,
      category_id: FactoryBot.create(:category).id
    )

    post recipes_path(as: user), params: { recipe: recipe_attributes }

    assert_redirected_to recipe_path(user.recipes.last)
  end

  test "GET edit as a guest redirects to sign-in" do
    recipe = FactoryBot.create(:recipe)

    get edit_recipe_path(recipe)

    assert_redirected_to sign_in_path
  end

  test "GET edit as the owner displays the edit form" do
    user = FactoryBot.create(:user)
    recipe = FactoryBot.create(:recipe, user: user)

    get edit_recipe_path(recipe, as: user)

    assert_response :success
  end

  test "GET edit as a non-owner returns 404" do
    user = FactoryBot.create(:user)
    recipe = FactoryBot.create(:recipe)

    get edit_recipe_path(recipe, as: user)

    assert_response :not_found
  end

  test "PATCH update as a guest redirects to sign-in and does not change the recipe" do
    recipe = FactoryBot.create(:recipe, name: "Old name")
    recipe_attributes = FactoryBot.attributes_for(:recipe,
      name: "New name",
      category_id: FactoryBot.create(:category).id
    )

    patch recipe_path(recipe), params: { recipe: recipe_attributes }

    assert_redirected_to sign_in_path
    assert_equal "Old name", recipe.reload.name
  end

  test "PATCH update as the owner updates the recipe" do
    user = FactoryBot.create(:user)
    recipe = FactoryBot.create(:recipe, user: user, name: "Old name")
    recipe_attributes = FactoryBot.attributes_for(:recipe,
      name: "New name",
      category_id: FactoryBot.create(:category).id
    )

    patch recipe_path(recipe, as: user), params: { recipe: recipe_attributes }

    assert_redirected_to recipe_path(recipe)
    assert_equal "New name", recipe.reload.name
  end

  test "PATCH update as a non-owner returns 404 and does not change the recipe" do
    user = FactoryBot.create(:user)
    recipe = FactoryBot.create(:recipe, name: "Old name")
    recipe_attributes = FactoryBot.attributes_for(:recipe,
      name: "New name",
      category_id: FactoryBot.create(:category).id
    )

    patch recipe_path(recipe, as: user), params: { recipe: recipe_attributes }

    assert_response :not_found
    assert_equal "Old name", recipe.reload.name
  end

  test "DELETE destroy as a guest redirects to sign-in and does not delete" do
    recipe = FactoryBot.create(:recipe)

    assert_no_difference("Recipe.count") do
      delete recipe_path(recipe)
    end

    assert_redirected_to sign_in_path
  end

  test "DELETE destroy as the owner deletes the recipe" do
    user = FactoryBot.create(:user)
    recipe = FactoryBot.create(:recipe, user: user)

    assert_difference("user.recipes.count", -1) do
      delete recipe_path(recipe, as: user)
    end

    assert_redirected_to recipes_path
  end

  test "DELETE destroy as a non-owner returns 404 and does not delete" do
    user = FactoryBot.create(:user)
    recipe = FactoryBot.create(:recipe)

    assert_no_difference("Recipe.count") do
      delete recipe_path(recipe, as: user)
    end

    assert_response :not_found
  end
end
