require "test_helper"

class RecipeTest < ActiveSupport::TestCase
  setup do
    @user = User.create(
      nickname: "test-user",
      email: "test-user@example.com",
      password: "password"
    )

    @category = Category.first
  end

  test "does not allow duplicate recipe names per user" do
    @user.recipes.create(
      name: "Test Recipe",
      category: @category
    )

    second_recipe = @user.recipes.build(name: "Test Recipe")

    assert_not second_recipe.valid?
    assert_includes second_recipe.errors[:name], "has already been taken"
  end

  test "allows two users to share a recipe name" do
    other_user = User.create(
      nickname: "another-test-user",
      email: "another-test-user@example.com",
      password: "password"
    )

    @user.recipes.create(
      name: "Test Recipe",
      category: @category
    )

    second_recipe = other_user.recipes.build(
      name: "Test Recipe",
      category: @category
    )

    assert second_recipe.valid?
  end

  test "finds recipes that contain the search term in their name" do
    first_recipe, second_recipe = create_search_recipes

    results = Recipe.by_word_in_name("pepperoni")

    assert_includes results, first_recipe
    assert_not_includes results, second_recipe
  end

  test "returns an empty collection when no recipes matching the search term are found" do
    create_search_recipes

    results = Recipe.by_word_in_name("veggie")

    assert_empty results
  end

  private

  def create_search_recipes
    first_recipe = @user.recipes.create(
      name: "Pepperoni Pizza",
      category: @category
    )

    second_recipe = @user.recipes.create(
      name: "Cheese Pizza",
      category: @category
    )

    [ first_recipe, second_recipe ]
  end
end
