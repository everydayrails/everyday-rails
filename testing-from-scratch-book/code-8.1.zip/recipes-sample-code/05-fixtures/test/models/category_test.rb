require "test_helper"

class CategoryTest < ActiveSupport::TestCase
  test "categories are available as fixtures" do
    assert_equal "Italian", categories(:italian).name
    assert_equal "Baking", categories(:baking).name
  end
end
