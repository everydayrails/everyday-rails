require "test_helper"

class RecipeTest < ActiveSupport::TestCase
  test "does not allow duplicate recipe names per user" do
    user = User.create(
      nickname: "test-user",
      email: "test-user@example.com",
      password: "password"
    )

    category = Category.create(name: "Test Category")

    user.recipes.create(
      name: "Test Recipe",
      category: category
    )

    second_recipe = user.recipes.build(name: "Test Recipe")

    assert_not second_recipe.valid?
    assert_includes second_recipe.errors[:name], "has already been taken"
  end

  test "allows two users to share a recipe name" do
    user = User.create(
      nickname: "test-user",
      email: "test-user@example.com",
      password: "password"
    )

    other_user = User.create(
      nickname: "another-test-user",
      email: "another-test-user@example.com",
      password: "password"
    )

    category = Category.create(name: "Test Category")

    user.recipes.create(
      name: "Test Recipe",
      category: category
    )

    second_recipe = other_user.recipes.build(
      name: "Test Recipe",
      category: category
    )

    assert second_recipe.valid?
  end

  test "finds recipes that contain the search term in their name" do
    user = User.create(
      nickname: "test-user",
      email: "test-user@example.com",
      password: "password"
    )

    category = Category.create(name: "Test Category")

    first_recipe = user.recipes.create(
      name: "Pepperoni Pizza",
      category: category
    )

    second_recipe = user.recipes.create(
      name: "Cheese Pizza",
      category: category
    )

    results = Recipe.by_word_in_name("pepperoni")

    assert_includes results, first_recipe
    assert_not_includes results, second_recipe
  end

  test "returns an empty collection when no recipes matching the search term are found" do
    user = User.create(
      nickname: "test-user",
      email: "test-user@example.com",
      password: "password"
    )

    category = Category.create(name: "Test Category")

    user.recipes.create(
      name: "Pepperoni Pizza",
      category: category
    )

    user.recipes.create(
      name: "Cheese Pizza",
      category: category
    )

    results = Recipe.by_word_in_name("veggie")

    assert_empty results
  end
end
