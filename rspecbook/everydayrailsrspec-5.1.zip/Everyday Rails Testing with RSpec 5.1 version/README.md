# Everyday Rails Testing with RSpec (Rails 5.1 edition)

Provided as-is. Support for this edition:
<https://github.com/everydayrails/everydayrails-rspec-2017>.

Visit <https://leanpub.com/everydayrailsrspec> for the latest edition.
