require "test_helper"

class WeeklyDigestJobTest < ActiveJob::TestCase
  # test "the truth" do
  #   assert true
  # end
end
