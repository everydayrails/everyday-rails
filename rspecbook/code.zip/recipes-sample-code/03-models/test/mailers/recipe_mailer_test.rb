require "test_helper"

class RecipeMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
