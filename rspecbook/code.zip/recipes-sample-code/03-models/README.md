# Everyday Rails Testing with RSpec sample code (Rails 7.1 edition, 2024)

Sample code for [Everyday Rails Testing with RSpec], Rails 7.1 edition.

- Download code from [book resource page]

[Everyday Rails Testing with RSpec]:https://leanpub.com/everydayrailsrspec
[book resource page]:https://everydayrails.com/rspecbook/
