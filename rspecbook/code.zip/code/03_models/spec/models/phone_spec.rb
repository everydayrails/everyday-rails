require 'spec_helper'

describe Phone do
  before :each do
    @contact = Contact.create(firstname: 'Joe', lastname: 'Tester',
      email: 'joetester@example.com')
  end

  it "does not allow duplicate phone numbers per contact" do
    home_phone = @contact.phones.create(phone_type: 'home', phone: '785-555-1234')
    mobile_phone = @contact.phones.build(phone_type: 'mobile', phone: '785-555-1234')
    expect(mobile_phone).to_not be_valid
  end

  it "allows two contacts to share a phone number" do
    @contact.phones.create(phone_type: 'home', phone: '785-555-1234')
    other_contact = Contact.new
    other_phone = other_contact.phones.build(phone_type: 'home', phone: '785-555-1234')
    expect(other_phone).to be_valid
  end
end