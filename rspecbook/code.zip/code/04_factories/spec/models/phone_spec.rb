require 'spec_helper'

describe Phone do
  it "has a valid factory" do
    expect(create(:phone)).to be_valid
  end

  it "does not allow duplicate phone numbers per contact" do
    contact = FactoryGirl.create(:contact)
    create(:home_phone,
      contact: contact,
      phone: "785-555-1234")
    expect(build(:work_phone, contact: contact, phone: "785-555-1234")).to_not be_valid
  end

  it "allows two contacts to share a phone number" do
    create(:home_phone,
      phone: "785-555-1234")
    expect(build(:home_phone, phone: "785-555-1234")).to be_valid
  end
end