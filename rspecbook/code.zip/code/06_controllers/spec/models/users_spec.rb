require 'spec_helper'

describe User do
  it "has a valid factory" do
    expect(create(:user)).to be_valid
  end

  it "has a valid admin factory" do
    expect(create(:admin)).to be_valid
  end
end