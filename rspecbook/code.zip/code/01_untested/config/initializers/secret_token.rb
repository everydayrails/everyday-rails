# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Contacts::Application.config.secret_token = 'c93551d965f6f4f4372a78a0733e3b63384b9ad3da4b04343c9d2eae06700e528416e0f10d2630b1ed9d0274fec2d345fe577bbcde5039c99ea48271ddf9328b'
